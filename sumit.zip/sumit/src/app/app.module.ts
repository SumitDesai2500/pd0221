
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';





import { AmazonComponent } from './amazon/amazon.component';


@NgModule({
  declarations: [
    AppComponent,
    
   
    
    
    AmazonComponent,
    
    
   
    
  
    
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    
    RouterModule.forRoot([
     
      { path: 'amazon', component:AmazonComponent},
   
      
  



    ])

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

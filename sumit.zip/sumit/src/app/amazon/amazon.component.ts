import { Amazons } from './../mock-data/amazons';
import { MockData } from './../mock-data';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amazon',
  templateUrl: './amazon.component.html',
  styleUrls: ['./amazon.component.css']
})
export class AmazonComponent implements OnInit {

  amazon:Amazons[]=[];
 
  constructor() { 
    this.amazon=MockData.amazon;
    
    
  }

  ngOnInit() {
  }

}

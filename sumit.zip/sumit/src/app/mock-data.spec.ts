import { MockData } from './mock-data';

describe('MockData', () => {
  it('should create an instance', () => {
    expect(new MockData()).toBeTruthy();
  });
});

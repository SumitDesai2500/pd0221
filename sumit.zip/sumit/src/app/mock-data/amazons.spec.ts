import { Amazons } from './amazons';

describe('Amazons', () => {
  it('should create an instance', () => {
    expect(new Amazons()).toBeTruthy();
  });
});
